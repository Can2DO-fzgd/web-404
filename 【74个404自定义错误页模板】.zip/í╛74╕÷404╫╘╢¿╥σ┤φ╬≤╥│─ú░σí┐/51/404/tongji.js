﻿//全景cnzz统计
document.writeln("<script src='http://w.cnzz.com/c.php?id=30037065' language='JavaScript' charset='gb2312'></script>");